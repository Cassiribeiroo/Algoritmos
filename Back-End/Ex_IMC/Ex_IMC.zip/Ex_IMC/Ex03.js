function calcular_imc() {
    const vet = [];
    do {

        let numero = parseInt(prompt("MENU \n1 - Cadastro \n2 - Imprimir lista \n3 - Encerrrar programa"));

        let pessoa = {};

        switch (numero) {
            case 1:
                pessoa.nome = prompt("Informe seu nome");
                pessoa.peso = parseFloat(prompt("Informe o seu peso em kg"));
                pessoa.altura = parseFloat(prompt("Informe a sua altura em metros"));
                pessoa.genero = prompt("Informe seu genero");

                pessoa.IMC = pessoa.peso / (pessoa.altura * pessoa.altura);

                vet.push(pessoa);

                if (pessoa.IMC < 18.5) {
                    console.log("CUIDADO, voce esta abaixo do seu peso normal.");
                }
                else if (pessoa.IMC >= 18.5 && pessoa.IMC < 25) {
                    console.log("CONTINUE ASSIM, voce esta no peso ideal.")
                }
                else if (pessoa.IMC >= 25 && pessoa.IMC < 30) {
                    console.log("CUIDADO, voce esta com excesso de peso.");
                }
                else if (pessoa.IMC >= 30 && pessoa.IMC < 35) {
                    console.log("CUIDADO, voce esta com obesidade de classe I.");
                }
                else if (pessoa.IMC >= 35 && pessoa.IMC < 40) {
                    console.log("CUIDADO, voce esta com obesidade de classe II.");
                }
                else if (pessoa.IMC >= 40) {
                    console.log("CUIDADO, voce esta com obesidade de classe III.");
                }
                break;

            case 2:
                console.table(vet);
                break;

            case 3:
                console.log("Encerrou o programa");
                return;
        }
    } while (true);
}