function calcular_imc() {
    const vet = [];
    do {

        let numero = parseInt(prompt("MENU \n1 - Cadastro \n2 - Imprimir lista \n3 - Encerrrar programa"));

        switch (numero) {
            case 1:
                let nome = prompt("Informe seu nome");
                vet.push(nome);
                let peso = parseFloat(prompt("Informe o seu peso em kg"));
                let altura = parseFloat(prompt("Informe a sua altura em metros"));
                let genero = prompt("Informe seu genero");

                let IMC = peso / (altura * altura);

                console.log("Nome: " + nome + "\nPeso: " + peso + "\nAltura: " + altura + "\nGenero: " + genero + "\nIMC: " + IMC);

                if (IMC < 18.5) {
                    console.log("CUIDADO, voce esta abaixo do seu peso normal.");
                }
                else if (IMC >= 18.5 && IMC < 25) {
                    console.log("CONTINUE ASSIM, voce esta no peso ideal.")
                }
                else if (IMC >= 25 && IMC < 30) {
                    console.log("CUIDADO, voce esta com excesso de peso.");
                }
                else if (IMC >= 30 && IMC < 35) {
                    console.log("CUIDADO, voce esta com obesidade de classe I.");
                }
                else if (IMC >= 35 && IMC < 40) {
                    console.log("CUIDADO, voce esta com obesidade de classe II.");
                }
                else if (IMC >= 40) {
                    console.log("CUIDADO, voce esta com obesidade de classe III.");
                }
                break;

            case 2:
                console.log(vet);
                break;

            case 3:
                console.log("Encerrou o programa");
                return;
        }
    } while (true);
}