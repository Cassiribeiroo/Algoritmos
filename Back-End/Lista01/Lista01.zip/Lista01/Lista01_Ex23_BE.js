/* Ex 23
Faça um algoritmo que receba o ano de nascimento de uma pessoa e o ano atual, calcule e mostre:
a idade dessa pessoa em anos;
a idade dessa pessoa em meses; 
a idade dessa pessoa em dias
a idade dessa pessoa em semanas. */

function calcular_idade() {
    let ano_nascimento = parseInt(prompt("Informe o ano de nascimento"));
    let ano_atual = parseInt(prompt("Informe o ano atual"));

    let idade_anos = ano_atual - ano_nascimento;
    let idade_meses = idade_anos * 12;
    let idade_dias = idade_anos * 365;
    let idade_semanas = idade_anos * 52;

    console.log("Idade em anos: " + idade_anos);
    console.log("Idade em meses: " + idade_meses);
    console.log("Idade em dias: " + idade_dias);
    console.log("Idade em semanas: " + idade_semanas);
}