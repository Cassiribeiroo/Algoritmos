/*Ex 01
A lanchonete Gostosura vende apenas um tipo de sanduíche, cujo recheio inclui duas fatias de queijo, uma fatia de presunto e uma rodela de hambúrguer. Sabendo que cada fatia de queijo ou presunto pesa 50 gramas, e que a rodela de hamburguer pesa 100 gramas, faça um algoritmo em que o dono forneça a quantidade de sanduiches a fazer, e a máquina informe as quantidades (em quilos) de queijo, presunto e carne necessários para compra. */

function calcularlanche() {
    let lanche = prompt("Informe a quantidade de sanduiches deseja fazer \n");

    let queijo = 0.1 * lanche;
    let hamburguer = 0.1 * lanche;
    let presunto = 0.05 * lanche;

    console.log("Sera necessario " + queijo + "kgs de queijo");
    console.log("Sera necessario " + presunto + "kgs de presunto");
    console.log("Sera necessario " + hamburguer + "kgs de hamburguer");
}