/* Ex 12
Faça um algoritmo que receba dois números, calcule e mostre a divisão do primeiro número pelo segundo. Sabe-se que o segundo número não pode ser zero, portanto não é necessário se preocupar com validações. */

function calcular_divisao() {
    let n1 = prompt("Informe o primeiro numero");
    let n2 = prompt("Informe o segundo numero");

    let divisao = (n1 / n2);

    console.log("Divisao: " + divisao);
}
