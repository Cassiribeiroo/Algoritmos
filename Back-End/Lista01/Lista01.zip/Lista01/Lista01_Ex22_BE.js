/* Ex 22
Faça um algoritmo que calcule e mostre a tabuada de um número digitado pelo usuário.  */

function calcular_tabuada() {
    let n = parseInt(prompt("Informe o numero que deseja calcular a tabuada"));

    console.log("TABUADA DO " + n);
    for (let i = 1; i <= 10; i++) {
        let x = (i * n);
        console.log(n + (" x ") + i + " = " + x);
    }
}