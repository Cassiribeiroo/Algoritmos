/* Ex 19
Faça um algoritmo que calcule e mostre a área de um quadrado. Sabe-se que: A = lado * lado; */

function calcular_quadrado() {
    let lado = prompt("Informe o lado do quadrado");

    let area = lado * lado;

    console.log("Area do quadrado: " + area);
}
