/* Ex 14
Faça um algoritmo que receba o preço de um produto, calcule e mostre o novo preço, sabendo-se que este sofreu um desconto de 10%. */

function calcular_produto() {
    let preco = prompt("Informe o preco do produto");

    let npreco = preco - (preco * 0.1);

    console.log("Novo preco: " + npreco.toFixed(2));
}