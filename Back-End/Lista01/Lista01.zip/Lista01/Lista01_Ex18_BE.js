/* Ex18
Faça um algoritmo que calcule e mostre a área de um trapézio. Sabe-se que: A = (base maior + base menor)* altura)/2 ; */

function calcular_trapezio() {
    let base_maior = parseFloat(prompt("Informe a base maior do trapezio"));
    let base_menor = parseFloat(prompt("Informe a base menor do trapezio"));
    let altura = parseFloat(prompt("Informe a altura do trapezio "));

    let area = ((base_maior * base_menor) * altura) / 2;

    console.log("Area do trapezio: " + area);
}
