/*Ex 02
Alguns países medem temperaturas em graus Celsius, e outros em graus Fahrenheit. Faça um algoritmo para ler uma temperatura Celsius e imprimi-Ia em Fahrenheit (pesquise como fazer este tipo de conversão). */

function converte_temperatura() {
    let Celsius = prompt("Informe  a temperatura em graus Celsius ");
    let Fahrenheit = (Celsius * (9 / 5)) + 32;
    console.log("Temperatura em Fahrenheit: " + Fahrenheit);
}