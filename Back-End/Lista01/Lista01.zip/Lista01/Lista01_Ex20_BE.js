/* Ex 20
Faça um algoritmo que calcule e mostre a área de um losango. Sabe-se que: A = (diagonal_maior * diagonal_menor)/2; */

function calcular_losango() {
    let diagonal_maior = parseFloat(prompt("Informe a diagonal maior"));
    let diagonal_menor = parseFloat(prompt("Informe a diagonal menor"));

    area = (diagonal_maior * diagonal_menor) / 2;

    console.log("Area do losango: " + area);

}