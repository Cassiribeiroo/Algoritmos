/* Ex 17
Faça um algoritmo que receba o peso de uma pessoa em quilos, calcule e mostre esse peso em gramas. */

function calcular_pesoGramas() {
    let pesok = parseFloat(prompt("Informe o peso em kg"));

    let pesog = parseFloat(pesok * 1000);

    console.log("Peso em gramas: " + pesog + "g");
}
