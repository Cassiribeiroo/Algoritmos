/* Ex 08
Num dia de sol, você deseja medir a altura de um prédio, porém, a trena não é suficientemente longa. Assumindo que seja possível medir sua sombra e a do prédio no chão, e que você lembre da sua altura, faça um algoritmo para ler os dados necessários e calcular a altura do prédio. */

function calcular_alturaPredio() {
    let sombra_predio = prompt("Informe o tamanho da sombra do predio em metros");
    let hpessoa = prompt("Informe a sua altura");
    let sombra_pessoa = prompt("Informe o tamanho da sua sombra em metros");

    let hpredio = (hpessoa * sombra_predio) / sombra_pessoa;

    console.log("Altura do predio: " + hpredio.toFixed(2) + " metros");
}