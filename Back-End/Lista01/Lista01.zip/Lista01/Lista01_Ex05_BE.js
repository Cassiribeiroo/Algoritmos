/* Uma confecção produz X blusas de lã e para isto gasta uma certa quantidade de novelos. Faça um algoritmo para calcular quantos novelos de lã ela gasta por blusa. */

function calcular_novelo() {
    let blusa = prompt("Informe a quantidade de blusas confeccionadas ");
    let novelo = prompt("Informe a quantidade de novelos utilizaados");
    let calculo = (novelo / blusa);

    console.log("Quantidade de novelos gastos por blusa: " + calculo);

}