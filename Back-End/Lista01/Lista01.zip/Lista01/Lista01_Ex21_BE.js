/* Ex 21
Faça um algoritmo que receba o valor do salário mínimo e o valor do salário de um funcionário, calcule e mostre a quantidade de salários mínimos que ganha esse funcionário.  */

function calcular_salarioMinimo() {
    let salario_minimo = parseFloat(prompt("Informe o valor do salario minimo"));
    let salario_funcionario = parseFloat(prompt("Informe o valor do salario do funcionario"));

    let n_salario = salario_funcionario / salario_minimo;

    console.log("Quantidade de salarios minimos: " + n_salario);
}