/* Ex 24
João recebeu seu salário de R$ 1200,00 e precisa pagar duas contas (C1=R$ 200,00 e C2=R$120,00) que estão atrasadas. Como as contas estão atrasadas, João terá de pagar multa de 2% sobre cada conta. Faça um algoritmo que calcule e mostre quanto restará do salário do João  */

function calcular_joao() {
    let salario = 1200;
    let contas = 320;

    let multa = contas * 0.02;

    let salario_joao = salario - (contas + multa);

    console.log("Restante do salario do Joao: " + salario_joao.toFixed(2) + "R$");
}