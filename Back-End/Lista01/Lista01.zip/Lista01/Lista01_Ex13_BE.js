/* Ex 13
Faça um algoritmo que receba duas notas, calcule e mostre a média ponderada dessas notas, considerando peso 2 para a primeira nota e peso 3 para a segunda nota.*/

function calcular_media() {
    let nota1 = prompt("Informe a primeira nota");
    let nota2 = prompt("Informe a segunda nota");

    let media = ((nota1 * 2) + (nota2 * 3)) / 5;

    console.log("Media ponderada: " + media);
}