/* Ex 07
Pedrinho tem um cofrinho com muitas moedas, e deseja saber quantos reais conseguiu poupar. Faça um algoritmo para ler a quantidade de cada tipo de moeda, e imprimir o valor total economizado, em reais. Considere que existam moedas de 1, 5, 10, 25 e 50 centavos, e ainda moedas de 1 real. Não havendo moeda de um tipo, a quantidade respectiva é zero. */

function calcular_moedas() {
    let moeda1C = prompt("Informe a quantidade de moedas de 1 centavo ");
    let moeda5C = prompt("Informe a quantidade de moedas de 5 centavos");
    let moeda10C = prompt("Informe a quantidade de moedas de 10 centavos");
    let moeda25C = prompt("Informe a quantidade de moedas de 25 centavos");
    let moeda50C = prompt("Informe a quantidade de moedas de 50 centavos ");
    let moeda1R = prompt("Informe a quantidade de moedas de 1 real");

    let valor = (moeda1C * 0.01) + (moeda5C * 0.05) + (moeda10C * 0.1) + (moeda25C * 0.25) + (moeda50C * 0.5) + (moeda1R * 1);

    console.log("Voce conseguiu poupar " + valor.toFixed(2) + " reais");
}