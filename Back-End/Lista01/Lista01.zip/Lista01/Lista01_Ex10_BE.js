/* Ex 10
Calcule o volume de uma caixa d'água cilíndrica. */

function calcular_caixaAgua() {
    let raio = prompt("Informe o raio do cilindro em centimetros");
    let altura = prompt("Informe a altura do cilindro em centimetros");

    let volume = 3.14 * (raio * raio) * altura;

    console.log("Volume da caixa d agua: " + volume + " centimetros cubicos");
}