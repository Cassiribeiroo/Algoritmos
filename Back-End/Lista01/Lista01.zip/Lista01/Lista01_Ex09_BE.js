/* Ex 09
Um tonel de refresco é feito com 8 partes de água mineral e 2 partes de suco de maracujá. Faça um algoritmo para calcular quantos litros de água e de suco são necessários para se fazer X litros de refresco (informados pelo usuário). */

function calcular_refresco() {
    let refresco = prompt("Informe a quantidade de litros de refresco deseja calcular");

    let agua = (refresco / 10) * 8;
    let suco = (refresco / 10) * 2;

    console.log("Sao necessarios " + agua.toFixed(3) + " litros de agua");
    console.log("São necessarios " + suco.toFixed(3) + " litros de suco");
}