/* Ex 16
Faça um algoritmo que receba o peso de uma pessoa, calcule e mostre: 
o novo peso se a pessoa engordar 15% sobre o peso digitado;
o novo peso se a pessoa emagrecer 20% sobre o peso digitado. */

function calcular_peso() {
    let peso = parseFloat(prompt("Informe o peso"));

    let pesoG = peso + (peso * 0.15);
    let pesoE = peso - (peso * 0.2);

    console.log("Novo peso se engordar 15 porcento " + pesoG.toFixed(2) + " kgs");
    console.log("Novo peso se emagrecer 20 porcento " + pesoE.toFixed(2) + " kgs");
}