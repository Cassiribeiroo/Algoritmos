/* Ex 04
A granja Frangotech possui um controle automatizado de cada frango da sua produção. No pé direito do frango há um anel com um chip de identificação; no pé esquerdo são dois anéis para indicar o tipo de alimento que ele deve consumir. Sabendo que o anel com chip custa R$4,00 e o anel de alimento custa R$3,50, faça um algoritmo para calcular o gasto total da granja para marcar todos os seus frangos. */

function calcular_frangos() {
    let informa_frango = prompt("Informe quantos frangos deseja marcar ");
    let valor_frango = (informa_frango * 7.50);

    console.log("Valor gasto para marcar os frangos " + valor_frango.toFixed(2) + " reais");
}