/* Ex 03
A empresa Hipotheticus paga R$10,00 por hora normal trabalhada, e R$15,00 por hora extra. Faça um algoritmo para calcular e imprimir o salário bruto e o salário líquido de um determinado funcionário. Considere que o salário líquido é igual ao salário bruto descontando-se 10% de impostos. */

function calcularsalario() {
    let hora_normal = prompt("Informe a quantidade de horas normais trabalhadas");
    let hora_extra = prompt("Informe a quantidade de horas extras trabalhadas");

    let salario_bruto = (hora_normal * 10.00) + (hora_extra * 15.00);
    let salario_liquido = salario_bruto - (salario_bruto * 0.1);

    console.log("Salario bruto: " + salario_bruto + " reais");
    console.log("Salario liquido: " + salario_liquido + " reais");
}