/* Ex 15
Um funcionário recebe um salário fixo mais 4% de comissão sobre as vendas. Faça um algoritmo que receba o salário fixo de um funcionário e o valor de suas vendas, calcule e mostre a comissão e o salário final do funcionário. */

function calcular_comissao() {
    let salario = parseFloat(prompt("Informe o salario para o calculo do salario final"));
    let vendas = parseFloat(prompt("Informe o valor das vendas para o calculo da comissao"));
    let comissao = parseFloat(vendas * 0.04);
    let salariofinal = parseFloat(salario + vendas + comissao);

    console.log("Comissao: " + comissao.toFixed(2) + " Reais");
    console.log("Salario final: " + salariofinal.toFixed(2) + " Reais");
}