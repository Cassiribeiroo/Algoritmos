/* Ex 06
A fábrica de refrigerantes Meia-Cola vende seu produto em três formatos: lata de 350 ml, garrafa de 600 ml e garrafa de 2 litros. Se um comerciante compra uma determinada quantidade de cada formato, faça um algoritmo para calcular quantos litros de refrigerante ele comprou. */

function calcular_refrigerante() {
    let lata = prompt("Informe a quantidade de latas deseja comprar");
    let garrafa = prompt("Informe a quantidade de garrafas de 600ml deseja comprar");
    let litro = prompt("Infore a quantidade de garradas de 2 litros deseja comprar");

    let total = (lata * 0.350) + (garrafa * 0.6) + (litro * 2);

    console.log("Quantidade de litros comprados: " + total.toFixed(3));
}