/* Ex 11
Faça um algoritmo que receba três números, calcule e mostre a multiplicação desses números.  */

function calcular_numeros() {
    let n1 = prompt("Informe o primeiro numero");
    let n2 = prompt("Informe o segundo numero ");
    let n3 = prompt("Informe o terceiro numero");

    let multiplicacao = n1 * n2 * n3;

    console.log("Multiplicacao dos numeros: " + multiplicacao);
}