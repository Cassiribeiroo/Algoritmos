/* Ex 25
Faça um algoritmo que receba o valor dos catetos de um triângulo, calcule e mostre o valor da hipotenusa.  */

function calcular_hipotenusa() {
    let c1 = parseFloat(prompt("Informe o valor do primeiro cateto do triangulo"));
    let c2 = parseFloat(prompt("Informe o valor do segundo cateto do triangulo"));

    let hip = Math.sqrt((c1 * c1) + (c2 * c2));

    console.log("Valor da hipotenusa do triangulo: " + hip);
}