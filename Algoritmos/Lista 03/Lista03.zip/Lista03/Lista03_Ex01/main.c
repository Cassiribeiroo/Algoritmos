#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;

    for (i=0; i<=20; i++){

        printf("Esta eh a mensagem %d \n",i);
    }

    return 0;
}
