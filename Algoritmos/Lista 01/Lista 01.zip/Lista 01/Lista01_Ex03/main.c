#include <stdio.h>
#include <stdlib.h>

int main()
{
float Nbroas, Ntotal;
int Npaes

 printf("Digite o numero de broas vendidas \n");



return 0;


}
