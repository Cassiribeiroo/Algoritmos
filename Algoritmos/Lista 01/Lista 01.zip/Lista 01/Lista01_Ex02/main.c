#include <stdio.h>
#include <stdlib.h>

int main()
{
    int Ncavalos;

    printf("Digite o numero de cavalos existentes no haras \n");
    scanf("%d",&Ncavalos);
    printf("\n Numero de ferraduras: %d",Ncavalos*4);
    return 0;
}




